﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class EditItem : Form
    {
        private string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;";
        private SqlConnection conn = null;
        private SqlCommand cmd = null;
        private string sql = null;
        private bool isEdit = false;
        private String passedSKU = "";

        public EditItem(Boolean edit, String SKU)
        {
            InitializeComponent();
            isEdit = edit;
            passedSKU = SKU;
            // Create a connection  
            conn = new SqlConnection(ConnectionString);
            // Open the connection  
            if (conn.State != ConnectionState.Open)
                conn.Open();
            if (isEdit == true)
            {
                try
                {
                    string SQLgetEdit = "SELECT * FROM inventoryTable WHERE SKU = '" + passedSKU + "'";
                    SqlCommand getPreviousData = new SqlCommand(SQLgetEdit, conn);
                    textBox1.Text = passedSKU;
                    using (SqlDataReader dr = getPreviousData.ExecuteReader())
                    {
                        dr.Read();
                        textBox2.Text = dr["Item_Name"].ToString();
                    };

                    using (SqlDataReader dr = getPreviousData.ExecuteReader())
                    {
                        dr.Read();
                        textBox3.Text = dr["Stock"].ToString();
                    };
                    
                    using (SqlDataReader dr = getPreviousData.ExecuteReader())
                    {
                        dr.Read();
                        textBox4.Text = dr["Price"].ToString();
                    };

                    using (SqlDataReader dr = getPreviousData.ExecuteReader())
                    {
                        dr.Read();
                        textBox5.Text = dr["New_Stock_Date"].ToString();
                    };

                    using (SqlDataReader dr = getPreviousData.ExecuteReader())
                    {
                        dr.Read();
                        textBox6.Text = dr["Incoming_Stock"].ToString();
                    };

                }
                catch (InvalidOperationException)
                {

                }
            }
        }

        private void btnAddEdit_Click(object sender, EventArgs e)
        {
            bool failedAttempt = false;
            
            // Create a connection  
            conn = new SqlConnection(ConnectionString);
            // Open the connection  
            if (conn.State != ConnectionState.Open)
                conn.Open();

            string SKU = "00000001";
            string itemName = "Unknown";
            int stock = 0;
            float price = 0.05F;
            string newStockDate = "00/00/00";
            int incomingStock = 0;

            SKU = textBox1.Text;
            itemName = textBox2.Text;

            //Convert to int
            //stock = textBox3.Text;
            try
            {
                stock = Int32.Parse(textBox3.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Unable to convert stock number to integer. Please try again");
                textBox3.Text = "0";
                failedAttempt = true;
            }

            //Convert to float
            //price = textBox4.Text;
            try
            {
                price = float.Parse(textBox4.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Unable to convert the price entered to a floating point number. Please try again");
                textBox3.Text = "0";
                failedAttempt = true;
            }

            newStockDate = textBox5.Text;

            //convert to int
            //incomingStock = textBox6.Text;
            try
            {
                incomingStock = Int32.Parse(textBox6.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Unable to convert incoming stock number to integer. Please try again");
                textBox6.Text = "0";
                failedAttempt = true;
            }

            if (failedAttempt == false && isEdit == false)
            {
                sql = "INSERT INTO inventoryTable(SKU, Item_Name, Stock, Price, New_Stock_Date, Incoming_Stock) " +
                "VALUES ('" + SKU + "', '" + itemName + "', '" + stock + "', '" + price + "', '" + newStockDate + "', '" + incomingStock + "' ) ";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                Close();
            }
            else if (failedAttempt == false && isEdit == true)
            {
                sql = "UPDATE inventoryTable SET SKU = '" + SKU + "', Item_Name = '" + itemName + "', Stock = '" + stock + "', Price = '" + price + "', " +
                    "New_Stock_Date = '" + newStockDate + "', Incoming_Stock = '" + incomingStock + "' WHERE SKU = '" + passedSKU + "'";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                if (conn.State == ConnectionState.Open)
                    conn.Close();
                Close();
            }
            if (conn.State == ConnectionState.Open)
                conn.Close();

        }
    }
}
