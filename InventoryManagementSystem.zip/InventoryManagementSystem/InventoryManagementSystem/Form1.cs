﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InventoryManagementSystem
{
    public partial class Form1 : Form
    {
        //private string dbLocation = "";
        private string ConnectionString = @"Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;";
        //private SqlDataReader reader = null;
        private SqlConnection conn = null;
        private SqlCommand cmd = null;
        private string sql = null;

        public Form1()
        {
            InitializeComponent();
            // Create a connection  
            conn = new SqlConnection(ConnectionString);
            // Open the connection  
            if (conn.State != ConnectionState.Open)
                conn.Open();
            //delete database and table from sql server
            //sql = "DROP DATABASE inventory";
            //ExecuteSQLStmt(sql);
            //sql = "DROP Table inventoryTable";
            //ExecuteSQLStmt(sql);
        }

        private void toolStripOpenDB_Click(object sender, EventArgs e)
        {
            //for future version to implement outside database
            //using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            //{
                //openFileDialog1.InitialDirectory = "c:\\";
                //openFileDialog1.Filter = "mdf files (*.mdf)|*.mdf";
                //openFileDialog1.FilterIndex = 2;
                //openFileDialog1.RestoreDirectory = true;

                //if (openFileDialog1.ShowDialog() == DialogResult.OK)
                //{
                    //string fileSelected = openFileDialog1.FileName;
                    //dbLocation = fileSelected;
                //}
            //}
            UpdateTable();
        }

        private void toolStripCreateDatabase_Click(object sender, EventArgs e)
        {
            
            string path = "";
            //Finds the path to store the newly created database and table
            using (FolderBrowserDialog openFolderBrowserDialog1 = new FolderBrowserDialog())
            {
                if (openFolderBrowserDialog1.ShowDialog() == DialogResult.OK)
                {
                    path = openFolderBrowserDialog1.SelectedPath;
                }
            }
            //textSearch.Text = path;
            
            // Create a connection  
            //conn = new SqlConnection(ConnectionString);
            // Open the connection  
            //if (conn.State != ConnectionState.Open)
                //conn.Open();
            sql = "CREATE DATABASE inventory ON PRIMARY"
            + "(Name=test_data, filename = '" + path + "\\inventory.mdf', size=3,"
            + "maxsize=5, filegrowth=10%)log on"
            + "(name=mydbb_log, filename = '" + path + "\\inventory.ldf',size=3,"
            + "maxsize=20,filegrowth=1)";
            ExecuteSQLStmt(sql);

            sql = "CREATE TABLE inventoryTable" +
            "(SKU CHAR(50) CONSTRAINT PKeyMyId PRIMARY KEY," +
            "Item_Name CHAR(50), Stock INTEGER, Price FLOAT, New_Stock_Date CHAR(50), Incoming_Stock INTEGER)";
            cmd = new SqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
                // Adding example records to the table  
                sql = "INSERT INTO inventoryTable(SKU, Item_Name, Stock, Price, New_Stock_Date, Incoming_Stock) " +
                "VALUES ('A1002E4', 'Tomatos', 43, 00.98, '12/17/21', 23 ) ";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                sql = "INSERT INTO inventoryTable(SKU, Item_Name, Stock, Price, New_Stock_Date, Incoming_Stock) " +
                "VALUES ('A1002E75', 'Apples', 97, 00.68, '12/17/21', 27 ) ";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                sql = "INSERT INTO inventoryTable(SKU, Item_Name, Stock, Price, New_Stock_Date, Incoming_Stock) " +
                "VALUES ('A2102S43', 'Lettuce', 15, 02.47, '12/17/21', 4 ) ";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                sql = "INSERT INTO inventoryTable(SKU, Item_Name, Stock, Price, New_Stock_Date, Incoming_Stock) " +
                "VALUES ('E1058E6', 'Strawberries', 82, 03.45, '12/17/21', 9 ) ";
                cmd = new SqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ae)
            {
                MessageBox.Show(ae.Message.ToString());
            }

            // Create a data adapter  
            SqlDataAdapter da = new SqlDataAdapter
            ("SELECT * FROM inventoryTable", conn);
            // Create DataSet, fill it and view in data grid  
            DataSet ds = new DataSet("inventoryTable");
            da.Fill(ds, "inventoryTable");
            dataGridView1.DataSource = ds.Tables["inventoryTable"].DefaultView;
        }

        private void toolStripExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void searchGo_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            SqlDataAdapter da = new SqlDataAdapter ("SELECT * FROM inventoryTable WHERE SKU LIKE '" + textSearch.Text + "'OR Item_Name LIKE '" + textSearch.Text +
            "'OR Stock LIKE '" + textSearch.Text + "'OR Price LIKE '" + textSearch.Text +
            "'OR New_Stock_Date LIKE '" + textSearch.Text + "'OR Incoming_Stock LIKE '" + textSearch.Text + "'", conn);
            da.Fill(ds, "inventoryTable");
            if (conn.State == ConnectionState.Open)
                conn.Close();
            dataGridView1.DataSource = ds.Tables["inventoryTable"];

            textSearch.Text = "";
        }

        //Executes an sql statement
        private void ExecuteSQLStmt(string sql)
        {
            if (conn.State == ConnectionState.Open)
                conn.Close();
            ConnectionString = @"Server=localhost\SQLEXPRESS;Database=master;Trusted_Connection=True;";
            conn.ConnectionString = ConnectionString;
            conn.Open();
            cmd = new SqlCommand(sql, conn);
            try
            {
                cmd.ExecuteNonQuery();
            }
            catch (SqlException ae)
            {
                MessageBox.Show(ae.Message.ToString());
            }
        }

        //Reload the database view
        private void UpdateTable()
        {
            try
            {
                // Create a data adapter  
                SqlDataAdapter da = new SqlDataAdapter
                ("SELECT * FROM inventoryTable", conn);
                // Create DataSet, fill it and view in data grid  
                DataSet ds = new DataSet("inventoryTable");
                da.Fill(ds, "inventoryTable");
                dataGridView1.DataSource = ds.Tables["inventoryTable"].DefaultView;
            }
            catch (SqlException ae)
            {
                MessageBox.Show("There is no database connected to the SQL server.");
            }
        }

        private void buttonQuickRemove_Click(object sender, EventArgs e)
        {
            try
            {
                int reducedStock = Int32.Parse(textBox2.Text);
                sql = "UPDATE inventoryTable SET Stock = Stock -'" + reducedStock + "' WHERE SKU = '" + textBox1.Text + "'";
                ExecuteSQLStmt(sql);
                UpdateTable();
            }
            catch (FormatException)
            {
                MessageBox.Show("Please enter a whole number to reduce the stock value.");
                textBox2.Text = "0";
            }
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            EditItem formAdd = new EditItem(false, "");
            //formAdd.Show();
            formAdd.FormClosed += delegate
            {
                UpdateTable();
            };
            formAdd.Show();
        }

        private void buttonRefresh_Click(object sender, EventArgs e)
        {
            UpdateTable();
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            string rowData = "";
            DataRowView dr = null;
            try
            {
                dr = dataGridView1.SelectedRows[0].DataBoundItem as DataRowView;
                if (dr != null)
                {
                    rowData = dr.Row["SKU"] as string;
                    //textSearch.Text = rowData;

                    sql = "DELETE FROM inventoryTable WHERE SKU = '" + rowData + "'";
                    ExecuteSQLStmt(sql);
                    UpdateTable();
                }
                else
                {
                    MessageBox.Show("Please Select an entire row to delete");
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Please Select an entire row to delete");
            }
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            string rowData = "";
            DataRowView dr = null;
            try
            {
                dr = dataGridView1.SelectedRows[0].DataBoundItem as DataRowView;
                if (dr != null)
                {
                    rowData = dr.Row["SKU"] as string;

                    EditItem formEdit = new EditItem(true, rowData);
                    //formAdd.Show();
                    formEdit.FormClosed += delegate
                    {
                        UpdateTable();
                    };
                    formEdit.Show();
                }
                else
                {
                    MessageBox.Show("Please Select an entire row to edit.");
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Please Select an entire row to edit.");
            }
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Help helpForm = new Help();
            helpForm.Show();
        }

        private void aboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutUs aboutForm = new AboutUs();
            aboutForm.Show();
        }
    }
}
